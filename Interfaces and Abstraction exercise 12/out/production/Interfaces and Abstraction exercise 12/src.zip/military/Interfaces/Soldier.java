package military.Interfaces;

public interface Soldier extends Private  {
    int getId();
    String getFirstName();
    String getLastName();
}
