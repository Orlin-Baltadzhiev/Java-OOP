package military.Interfaces;

public interface LieutenantGeneral extends  Soldier {
    void addPrivate(Private priv);
}
