package military.Interfaces;

public interface Repair {
}
