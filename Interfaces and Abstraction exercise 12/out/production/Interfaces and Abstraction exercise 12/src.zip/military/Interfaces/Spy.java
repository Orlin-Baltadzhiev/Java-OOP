package military.Interfaces;

public interface Spy {
}
