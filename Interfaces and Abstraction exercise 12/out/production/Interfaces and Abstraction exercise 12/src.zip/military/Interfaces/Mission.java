package military.Interfaces;

public interface Mission {
    void completeMission();
}
