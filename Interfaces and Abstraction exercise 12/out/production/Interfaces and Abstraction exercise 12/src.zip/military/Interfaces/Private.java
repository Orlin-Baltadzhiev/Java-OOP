package military.Interfaces;

public interface Private {
    double getSalary();
}
