package military.Interfaces;

public interface SpecialisedSoldier extends Soldier {
}
