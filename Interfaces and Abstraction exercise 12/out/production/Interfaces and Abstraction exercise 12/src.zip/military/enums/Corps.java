package military.enums;

public enum  Corps {
    AIRFORCES,
    MARINES
}
