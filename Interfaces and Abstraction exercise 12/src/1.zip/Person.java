public interface Person {
    public abstract String getName();
    public abstract int getAge();

}
