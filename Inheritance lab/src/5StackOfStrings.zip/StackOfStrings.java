import java.util.ArrayList;
import java.util.NoSuchElementException;

public class StackOfStrings {

    private ArrayList<String> data;
    private int lastElementIndex;

    public StackOfStrings() {
        this.data=new ArrayList<>();
        this.lastElementIndex=-1;
    }

    public void push(String element) {
        this.lastElementIndex++;
        this.data.add(element);
    }
    public String pop(){
        int lastElementIndex = this.data.size()-1;
        ensureNonEmpty();
        return this.data.remove(this.lastElementIndex--);
    }

    private void ensureNonEmpty(){
        if(this.lastElementIndex<0){
            throw  new NoSuchElementException("No such element");
        }
    }

    public String peek(){
        ensureNonEmpty();
        return this.data.get(this.lastElementIndex);


    }

    public Boolean isEmpty(){
        return this.data.isEmpty();
    }
}
