package Zoo;

public class Puppy extends  Dog {

    public void week(){
        System.out.println("weeping...");
    }
}
