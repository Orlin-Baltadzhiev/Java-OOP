package Animals;

public class Cat extends Animal {

    private static final Gender GENDER = Gender.FEMALE;
    public Cat(String name, int age,Gender gender) {
        super(name, age, GENDER);
    }
    @Override
    public String produceSound(){
        return "Meow meow";
    }
}
