package Animals;



public class Animal {
    private String name;
    private int age;
    private Gender gender;

    public Animal(String name, int age, Gender gender) {
        this.name = name;
        this.age = age;
        this.gender = gender;
    }

    @Override
    public String toString() {
        return String.format("%s%n%s %d %s",this.getClass().getSimpleName(),this.name,this.age,this.gender.toString());
    }

    public String produceSound() {
        return "";
    }
}
