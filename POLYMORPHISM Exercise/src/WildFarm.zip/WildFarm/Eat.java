package WildFarm;

public interface Eat {
    void eat(Food food);
}
