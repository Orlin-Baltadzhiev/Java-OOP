package WildFarm;

public interface ProduceSound {
    void makeSound();
}
