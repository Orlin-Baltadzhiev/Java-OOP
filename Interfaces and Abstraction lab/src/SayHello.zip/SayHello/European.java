package SayHello;

public class European extends BasePerson {
    protected European(String name) {
        super(name);
    }
}
