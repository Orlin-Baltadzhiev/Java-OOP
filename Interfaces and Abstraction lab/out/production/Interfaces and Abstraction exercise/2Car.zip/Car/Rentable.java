package Car;

public interface Rentable {

    Integer getMinRentDay();
    Double getPricePerDay();
}
