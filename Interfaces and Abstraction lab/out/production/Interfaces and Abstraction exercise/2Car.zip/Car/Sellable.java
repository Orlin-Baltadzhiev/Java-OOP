package Car;

public interface Sellable {
    Double getPrice();
}
