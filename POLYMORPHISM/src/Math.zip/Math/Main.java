package Math;

public class Main {

    public static void main(String[] args) {

    Shape first = new Circle(12D);

        System.out.println(first.calculateArea());
        System.out.println(first.calculatePerimeter());

    }
}
