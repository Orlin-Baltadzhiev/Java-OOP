public class ExitCommand {

    public String execute(){
        return "Exit";
    }
}
