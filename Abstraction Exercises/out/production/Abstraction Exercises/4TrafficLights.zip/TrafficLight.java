public enum TrafficLight {
    RED,
    GREEN,
    YELLOW;
}
