package barracksWars.models.units;

public class   Wizard extends AbstractUnit  {
    public Wizard() {
        super(100, 500);
    }
}
